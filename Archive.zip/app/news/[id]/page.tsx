'use client'

import { useEffect, useState } from 'react'
import HttpService from '@/app/services/http.service'
import { useParams } from 'next/navigation'

const http = new HttpService()

interface NewsDetailsType {
  id: number
  title: string
  description: string
  file_id: { path: string }
  date: string
}

const NewsDetails = () => {
  const params = useParams()

  const [newsDetails, setNewsDetails] = useState<NewsDetailsType | null>(null)

  useEffect(() => {
    console.log(params.id)

    // Check if the router is ready and the id exists
    if (params.id) {
      http
        .get(`/news/${params.id}`)
        .then((res: any) => {
          console.log(res)
          setNewsDetails(res[0])
        })
        .catch(err => {
          console.error('Error fetching news details:', err)
        })
    }
  }, [params.id])

  if (!newsDetails) {
    return (
      <div className='container mx-auto py-10 px-4'>
        <div className='flex items-center justify-center min-h-[60vh]'>
          <div className='animate-pulse text-xl'>درحال لود شدن...</div>
        </div>
      </div>
    )
  }

  return (
    <article className='min-h-screen bg-gray-50 dark:bg-dark'>
      {/* Hero Section with Image */}
      <div className='relative h-[400px] md:h-[500px] w-full'>
        <img src={newsDetails?.file_id?.path} alt={newsDetails.title} className='w-full h-full object-cover' />
        <div className='absolute inset-0 bg-gradient-to-t from-black/80 to-transparent' />
        <div className='absolute bottom-0 left-0 right-0 p-8 md:p-12'>
          <div className='container mx-auto'>
            <span className='inline-block px-4 py-2 mb-4 text-sm font-medium bg-white/20 backdrop-blur-sm rounded-full text-white'>
              {new Date(newsDetails.date).toLocaleDateString('fa-IR')}
            </span>
            <h1 className='text-3xl md:text-5xl font-bold text-white mb-4'>{newsDetails.title}</h1>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className='container mx-auto px-4 py-12 md:py-16'>
        <div className='max-w-4xl mx-auto'>
          <div className='prose prose-lg dark:prose-invert max-w-none'>
            <p className='text-lg md:text-xl leading-relaxed text-gray-700 dark:text-gray-300 whitespace-pre-line'>
              {newsDetails.description}
            </p>
          </div>

          {/* Share and Actions */}
          <div className='mt-12 pt-8 border-t border-gray-200 dark:border-gray-700'>
            <div className='flex items-center justify-between'>
              <div className='flex items-center space-x-4 rtl:space-x-reverse'>
                <button className='px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors'>
                  اشتراک گذاری
                </button>
                <button className='px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors'>
                  چاپ
                </button>
              </div>
              <a href='/news' className='text-primary hover:text-primary/80 transition-colors'>
                بازگشت به اخبار
              </a>
            </div>
          </div>
        </div>
      </div>
    </article>
  )
}

export default NewsDetails
