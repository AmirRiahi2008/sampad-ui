'use client'

import HttpService from '@/app/services/http.service'
import { useEffect, useState } from 'react'
import Card from '../shared/MainCard'

const http = new HttpService()

interface NewsDataType {
  id: number
  file_id: { path: string }
  title: string
  description: string
  date: string
  isFlagged: boolean
}

const News = () => {
  const [latestNews, setLatestNews] = useState<NewsDataType[]>()

  useEffect(() => {
    http.get('/news').then((res: any) => {
      console.log(res)
      setLatestNews(res)
    })
  }, [])

  return (
    <section className='pb-10 pt-20 dark:bg-dark lg:pb-20 lg:pt-[120px]'>
      <div className='container mx-auto px-4'>
        <div className='mb-[60px] text-center'>
          <h2 className='mb-3 text-3xl font-bold leading-[1.2] text-dark dark:text-white sm:text-4xl md:text-[40px]'>
            جدید ترین خبر ها
          </h2>
        </div>
        <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6'>
          {latestNews?.map((item: NewsDataType) => (
            <Card key={item.id} id={item.id} title={item.title} imageSrc={item.file_id.path} />
          ))}
        </div>
      </div>
    </section>
  )
}

export default News
