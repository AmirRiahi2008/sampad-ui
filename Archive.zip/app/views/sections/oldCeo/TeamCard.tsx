const TeamCard = ({ name, profession, imageSrc }: { name: string; profession: string; imageSrc: string }) => {
  return (
    <div className='bg-white shadow-md rounded-lg overflow-hidden transform transition-transform hover:scale-105 duration-300'>
      <div className='w-full h-64 overflow-hidden'>
        <img src={imageSrc} alt={name} className='w-full h-full object-cover' />
      </div>
      <div className='p-4 text-center'>
        <h3 className='text-lg font-bold text-primary'>{name}</h3>
        <p className='text-sm text-gray-600'>{profession}</p>
      </div>
    </div>
  )
}

export default TeamCard
