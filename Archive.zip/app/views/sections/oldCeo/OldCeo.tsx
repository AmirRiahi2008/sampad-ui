'use client'
import { Suspense } from 'react'
import dynamic from 'next/dynamic'
import { motion } from 'framer-motion'

// Dynamically import TeamCard
const TeamCard = dynamic(() => import('./TeamCard'), {
  suspense: true
})

const Team = () => {
  // Animation variants for Framer Motion
  const cardVariants = {
    hidden: { opacity: 0, y: 50 }, // Initial state: offscreen and transparent
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } } // Animate in with fade and slide
  }

  return (
    <section className='pb-10 pt-20 dark:bg-dark lg:pb-20 lg:pt-[120px]'>
      <div className='container mx-auto'>
        <div className='text-center mb-12'>
          <h2 className='relative inline-block text-4xl font-extrabold text-primary dark:text-white'>
            مدیران سابق
            <span className='absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-16 h-1 bg-primary'></span>
          </h2>
          <p className='mt-4 text-gray-500 text-sm md:text-base'>
            مدیران پیشین ما که در این سال‌ها باعث پیشرفت مجموعه شده‌اند.
          </p>
        </div>

        {/* Grid Layout */}
        <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 justify-center'>
          <Suspense fallback={<div>Loading...</div>}>
            <motion.div
              initial='hidden'
              whileInView='visible'
              viewport={{ once: true, amount: 0.3 }}
              variants={cardVariants}
            >
              <TeamCard name='علی اکبر صادقیان' profession='1373-1369' imageSrc='assets/static/20240819_111029.jpg' />
            </motion.div>
          </Suspense>
          <Suspense fallback={<div>Loading...</div>}>
            <motion.div
              initial='hidden'
              whileInView='visible'
              viewport={{ once: true, amount: 0.3 }}
              variants={cardVariants}
            >
              <TeamCard name='یارعلی بادله' profession='1375-1373' imageSrc='assets/static/20240819_111147.jpg' />
            </motion.div>
          </Suspense>
          <Suspense fallback={<div>Loading...</div>}>
            <motion.div
              initial='hidden'
              whileInView='visible'
              viewport={{ once: true, amount: 0.3 }}
              variants={cardVariants}
            >
              <TeamCard name='غلام رضا بهروان' profession='1378-1375' imageSrc='assets/static/20240819_111130.jpg' />
            </motion.div>
          </Suspense>
          <Suspense fallback={<div>Loading...</div>}>
            <motion.div
              initial='hidden'
              whileInView='visible'
              viewport={{ once: true, amount: 0.3 }}
              variants={cardVariants}
            >
              <TeamCard name='علی درویش متولی' profession='1393-1387' imageSrc='assets/static/20240819_111103.jpg' />
            </motion.div>
          </Suspense>
          <Suspense fallback={<div>Loading...</div>}>
            <motion.div
              initial='hidden'
              whileInView='visible'
              viewport={{ once: true, amount: 0.3 }}
              variants={cardVariants}
            >
              <TeamCard name='سید محمد آقامیری' profession='1387-1381' imageSrc='assets/static/20240819_111112.jpg' />
            </motion.div>
          </Suspense>
          <Suspense fallback={<div>Loading...</div>}>
            <motion.div
              initial='hidden'
              whileInView='visible'
              viewport={{ once: true, amount: 0.3 }}
              variants={cardVariants}
            >
              <TeamCard name='مصطفی حسینی' profession='1400-1393' imageSrc='assets/static/20240819_111055.jpg' />
            </motion.div>
          </Suspense>
        </div>
      </div>
    </section>
  )
}

export default Team
