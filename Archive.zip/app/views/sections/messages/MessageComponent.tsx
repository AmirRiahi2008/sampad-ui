'use client'

import { Swiper, SwiperSlide } from 'swiper/react'
import { Autoplay, Pagination } from 'swiper/modules' // Import Autoplay and Pagination modules
import 'swiper/css'
import 'swiper/css/autoplay'
import 'swiper/css/pagination'

import HttpService from '@/app/services/http.service'
import { useEffect, useState } from 'react'

const http = new HttpService()

const MessageQuoteSlider = () => {
  const [messages, setMessages] = useState<any>([])

  useEffect(() => {
    http.get('manager-notification').then((res: any) => {
      setMessages(res)
    })
  }, [])

  return (
    <div className='relative bg-white text-gray-900 py-12'>
      <div className='container mx-auto'>
        {/* Title Section */}
        <div className='text-center mb-12'>
          <span className='inline-block px-4 py-1 mb-4 text-sm font-medium bg-primary/10 text-primary rounded-full'>
            پیام‌های مدیریت
          </span>
          <h2 className='text-3xl md:text-4xl font-bold mb-4 text-gray-900'>آخرین پیام‌های مدیران</h2>
          <p className='text-gray-600 max-w-2xl mx-auto'>
            آخرین پیام‌های مدیران برای دانش‌آموزان و اولیا جهت اطلاع‌رسانی و انگیزه‌بخشی
          </p>
        </div>

        {/* Swiper Section */}
        <div className='w-full max-w-3xl mx-auto'>
          <Swiper
            modules={[Autoplay, Pagination]}
            autoplay={{
              delay: 5000,
              disableOnInteraction: false
            }}
            pagination={{
              clickable: true,
              bulletClass: 'swiper-pagination-bullet !bg-gray-300',
              bulletActiveClass: 'swiper-pagination-bullet-active !bg-primary'
            }}
            spaceBetween={20}
            slidesPerView={1}
            loop
            className='mySwiper'
          >
            {messages?.map((item: any) => (
              <SwiperSlide key={item.id}>
                <div className='bg-white rounded-xl shadow-md p-6 md:p-8 flex flex-col items-center text-center border border-gray-100 hover:border-primary/50 transition-colors duration-300'>
                  <div className='w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center'>
                    <svg className='w-6 h-6 text-primary' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                      <path
                        strokeLinecap='round'
                        strokeLinejoin='round'
                        strokeWidth={2}
                        d='M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z'
                      />
                    </svg>
                  </div>
                  <h3 className='text-xl md:text-2xl font-bold text-gray-900 mb-4'>{item.title}</h3>
                  <p className='text-gray-600 text-base leading-relaxed mb-6'>{item.description}</p>
                  <div className='flex items-center text-sm text-gray-500'>
                    <svg className='w-4 h-4 ml-2' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                      <path
                        strokeLinecap='round'
                        strokeLinejoin='round'
                        strokeWidth={2}
                        d='M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z'
                      />
                    </svg>
                    <span>{new Date(item.date).toLocaleDateString('fa-IR')}</span>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </div>
  )
}

export default MessageQuoteSlider
