'use client'

import HttpService from '@/app/services/http.service'
import { useEffect, useState } from 'react'
import { Swiper, SwiperSlide } from 'swiper/react'
import { Autoplay, Navigation, Pagination } from 'swiper/modules'
import 'swiper/css'
import 'swiper/css/autoplay'
import 'swiper/css/pagination'
import 'swiper/css/navigation'
import Link from 'next/link'

const http = new HttpService()

interface NewsDataType {
  id: number
  file_id: { path: string }
  title: string
  description: string
  date: string
  isFlagged: boolean
}

const LatestNews = () => {
  const [latestNews, setLatestNews] = useState<NewsDataType[]>([])

  useEffect(() => {
    http.get('/news/getFlaggedNews').then((res: any) => {
      setLatestNews(res)
    })
  }, [])

  return (
    <section className='relative w-full h-screen'>
      <Swiper
        modules={[Autoplay, Pagination, Navigation]}
        autoplay={{
          delay: 5000,
          disableOnInteraction: false
        }}
        pagination={{
          clickable: true,
          dynamicBullets: true,
          bulletClass: 'swiper-pagination-bullet',
          bulletActiveClass: 'swiper-pagination-bullet-active'
        }}
        navigation={{
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }}
        spaceBetween={0}
        slidesPerView={1}
        loop
        className='h-full'
      >
        {latestNews?.map(item => (
          <SwiperSlide key={item.id} className='relative'>
            {/* Background Image with Overlay */}
            <div className='absolute inset-0 w-screen h-4/5 mt-36'>
              <img src={item.file_id.path} alt={item.title} className='w-full h-full object-cover object-center' />
              <div className='absolute inset-0 bg-gradient-to-r from-black/80 to-black/40' />
            </div>

            {/* Content */}
            <div className='relative h-full flex items-center'>
              <div className='container mx-auto px-4 md:px-8 max-w-7xl'>
                <div className='max-w-2xl text-white'>
                  <span className='inline-block px-4 py-1 mb-4 text-sm font-medium bg-white/20 backdrop-blur-sm rounded-full'>
                    {new Date(item.date).toLocaleDateString()}
                  </span>
                  <h3 className='text-4xl md:text-6xl font-bold mb-4 leading-tight'>{item.title}</h3>
                  <p className='text-lg md:text-xl text-white/80 mb-8'>{item.description}</p>
                  <Link
                    href={`/news/${item.id}`}
                    className='px-8 py-3 bg-white text-black font-medium rounded-full hover:bg-white/90 transition-colors'
                  >
                    ادامه مطلب
                  </Link>
                </div>
              </div>
            </div>
          </SwiperSlide>
        ))}

        {/* Custom Navigation Buttons */}
        <div className='swiper-button-next swiper-button-white' />
        <div className='swiper-button-prev swiper-button-white' />
      </Swiper>
      <style jsx global>{`
        .swiper-pagination-bullet {
          background: rgba(255, 255, 255, 0.5);
        }
        .swiper-pagination-bullet-active {
          background: white;
        }
        .swiper-button-next,
        .swiper-button-prev {
          color: white;
        }
        .swiper-button-next:after,
        .swiper-button-prev:after {
          font-size: 2rem;
        }
      `}</style>
    </section>
  )
}

export default LatestNews
