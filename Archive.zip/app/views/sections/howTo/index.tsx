'use client'
import { FaGraduationCap, FaChalkboardTeacher, FaFlask } from 'react-icons/fa'
import { motion } from 'framer-motion'

const AboutSection = () => {
  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  }

  return (
    <div className='bg-gray-50 py-24'>
      <section id='about' className='container mx-auto px-6 md:px-10'>
        {/* Section Title */}
        <motion.div
          initial='hidden'
          whileInView='visible'
          viewport={{ once: true, amount: 0.3 }}
          variants={cardVariants}
          className='max-w-3xl mx-auto text-center mb-16'
        >
          <span className='inline-block px-4 py-1 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4'>
            درباره ما
          </span>
          <h2 className='text-3xl md:text-4xl font-bold text-gray-900 mb-6'>همراهی برای ساختن آینده‌ای روشن</h2>
          <p className='text-gray-600 leading-relaxed'>
            با ارائه آموزش‌های تخصصی، محیطی پیشرفته، و اساتید برجسته، ما به دانش‌آموزان کمک می‌کنیم تا به بهترین نسخه از
            خود تبدیل شوند.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto'>
          {/* Feature 1 */}
          <motion.div
            initial='hidden'
            whileInView='visible'
            viewport={{ once: true, amount: 0.3 }}
            variants={cardVariants}
            className='bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow duration-300 border border-gray-100'
          >
            <div className='w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6'>
              <FaGraduationCap className='text-2xl text-primary' />
            </div>
            <h3 className='text-xl font-bold text-gray-900 mb-4'>برنامه‌های جامع آموزشی</h3>
            <p className='text-gray-600 leading-relaxed'>
              برنامه‌های آموزشی ما متناسب با نیازهای دانش‌آموزان طراحی شده است تا آن‌ها را برای آزمون‌های کنکور و موفقیت
              در زندگی آماده کند.
            </p>
          </motion.div>

          {/* Feature 2 */}
          <motion.div
            initial='hidden'
            whileInView='visible'
            viewport={{ once: true, amount: 0.3 }}
            variants={cardVariants}
            className='bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow duration-300 border border-gray-100'
          >
            <div className='w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6'>
              <FaFlask className='text-2xl text-primary' />
            </div>
            <h3 className='text-xl font-bold text-gray-900 mb-4'>محیط‌های پیشرفته و علمی</h3>
            <p className='text-gray-600 leading-relaxed'>
              امکانات مدرن از جمله آزمایشگاه‌های تخصصی، سالن‌های مطالعه، و کارگاه‌های فناوری برای دانش‌آموزان فراهم شده
              است.
            </p>
          </motion.div>

          {/* Feature 3 */}
          <motion.div
            initial='hidden'
            whileInView='visible'
            viewport={{ once: true, amount: 0.3 }}
            variants={cardVariants}
            className='bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow duration-300 border border-gray-100'
          >
            <div className='w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6'>
              <FaChalkboardTeacher className='text-2xl text-primary' />
            </div>
            <h3 className='text-xl font-bold text-gray-900 mb-4'>اساتید برجسته</h3>
            <p className='text-gray-600 leading-relaxed'>
              همکاری با اساتید مجرب و مربیان متخصص به دانش‌آموزان کمک می‌کند که بهترین راهنمایی‌ها و آموزش‌ها را دریافت
              کنند.
            </p>
          </motion.div>
        </div>

        {/* Call to Action */}
        <motion.div
          initial='hidden'
          whileInView='visible'
          viewport={{ once: true, amount: 0.3 }}
          variants={cardVariants}
          className='mt-16 text-center'
        >
          <a
            href='#contact'
            className='inline-flex items-center px-6 py-3 bg-primary/10 text-primary font-medium rounded-full hover:bg-primary hover:text-white transition-colors duration-300'
          >
            با ما تماس بگیرید
            <svg className='w-5 h-5 mr-2 rtl:rotate-180' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
              <path strokeLinecap='round' strokeLinejoin='round' strokeWidth='2' d='M17 8l4 4m0 0l-4 4m4-4H3' />
            </svg>
          </a>
        </motion.div>
      </section>
    </div>
  )
}

export default AboutSection
