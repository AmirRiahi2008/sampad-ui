'use client'
import { FaChalkboardTeacher } from 'react-icons/fa'
import { IoIosSchool } from 'react-icons/io'
import { IoSchool } from 'react-icons/io5'
import { motion } from 'framer-motion'

const SchoolService = () => {
  // Framer Motion Variants
  const textVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  }

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.5 } }
  }

  return (
    <div className='bg-gradient-to-b from-gray-900 to-gray-800 text-white py-16'>
      <section id='features' className='container mx-auto px-6 md:px-10'>
        {/* Title Section */}
        <motion.div
          initial='hidden'
          whileInView='visible'
          viewport={{ once: true, amount: 0.3 }}
          variants={textVariants}
          className='text-center'
        >
          <h3 className='text-lg font-medium text-gray-400 uppercase tracking-widest mb-4'>
            چرا باید ما را انتخاب کنید؟
          </h3>
          <h2 className='text-4xl font-extrabold text-white mb-6'>بهترین انتخاب برای موفقیت در آینده</h2>
          <p className='text-lg text-gray-300 max-w-3xl mx-auto'>
            مدارس سمپاد با ارائه محیطی پیشرفته و برنامه‌ای جامع، دانش‌آموزان را برای موفقیت در آزمون‌های سراسری کنکور و
            المپیادهای علمی آماده می‌کنند. هدف ما رشد علمی و تربیتی دانش‌آموزان است.
          </p>
        </motion.div>

        {/* Features Section */}
        <motion.div
          initial='hidden'
          whileInView='visible'
          viewport={{ once: true, amount: 0.3 }}
          className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12'
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                delayChildren: 0.3,
                staggerChildren: 0.2
              }
            }
          }}
        >
          {/* Feature 1 */}
          <motion.div
            variants={cardVariants}
            className='bg-gray-800 rounded-lg shadow-md p-8 hover:shadow-lg transition-shadow duration-300'
          >
            <div className='flex items-center justify-center h-16 w-16 mx-auto bg-primary rounded-full text-white'>
              <IoSchool className='text-3xl' />
            </div>
            <h3 className='text-xl font-bold text-white mt-6 text-center'>برنامه درسی جامع</h3>
            <p className='text-gray-400 text-center mt-4'>
              ارائه برنامه‌های درسی متنوع و تخصصی با تمرکز بر نیازهای آموزشی دانش‌آموزان، به همراه افزایش کیفیت یادگیری
              و عملکرد تحصیلی.
            </p>
          </motion.div>

          {/* Feature 2 */}
          <motion.div
            variants={cardVariants}
            className='bg-gray-800 rounded-lg shadow-md p-8 hover:shadow-lg transition-shadow duration-300'
          >
            <div className='flex items-center justify-center h-16 w-16 mx-auto bg-primary rounded-full text-white'>
              <IoIosSchool className='text-3xl' />
            </div>
            <h3 className='text-xl font-bold text-white mt-6 text-center'>امکانات پیشرفته</h3>
            <p className='text-gray-400 text-center mt-4'>
              آزمایشگاه‌های مجهز، سالن‌های مطالعه، کارگاه‌های کامپیوتر و امکانات پیشرفته برای فراهم کردن بهترین شرایط
              یادگیری.
            </p>
          </motion.div>

          {/* Feature 3 */}
          <motion.div
            variants={cardVariants}
            className='bg-gray-800 rounded-lg shadow-md p-8 hover:shadow-lg transition-shadow duration-300'
          >
            <div className='flex items-center justify-center h-16 w-16 mx-auto bg-primary rounded-full text-white'>
              <FaChalkboardTeacher className='text-3xl' />
            </div>
            <h3 className='text-xl font-bold text-white mt-6 text-center'>اساتید برجسته</h3>
            <p className='text-gray-400 text-center mt-4'>
              همکاری با برترین اساتید، مربیان و مشاوران متخصص، به همراه استفاده از تجربه فارغ‌التحصیلان موفق برای رشد
              مهارت‌ها و دانش‌آموزان.
            </p>
          </motion.div>
        </motion.div>
      </section>
    </div>
  )
}

export default SchoolService
