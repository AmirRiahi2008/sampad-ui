import { AuthProvider } from '../context/AuthContext'

interface LayoutProps {
  children: React.ReactNode
}

const Layout = ({ children }: LayoutProps): React.JSX.Element => {
  return <AuthProvider>{children}</AuthProvider>
}
export default Layout
