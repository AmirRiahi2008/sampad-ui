export enum ProjectStatus {
    Aktiv = 1,
    Inaktiv,
    Offen,
    Abgeschlossen
  }