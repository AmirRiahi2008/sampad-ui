'use client'
import Image from 'next/image'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import HttpService from '@/app/services/http.service'
import toast from 'react-hot-toast'

const http = new HttpService()

interface CourseType {
  id: number
  title: string
  seats: string
  description: string
  imageSrc?: string
  href: string
}

export default function CoursesList(): JSX.Element {
  const [courses, setCourses] = useState<CourseType[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchCourses() {
      try {
        const res: any = await http.get(`${process.env.NEXT_PUBLIC_API_URL}/courses`)
        const formatted = res
          .filter((course: any) => course.isActive === true)
          .map((course: any) => ({
            id: course.id,
            title: course.name,
            seats: course.seats,
            description: course.description || 'توضیحی موجود نیست',
            href: `/courses/register/${encodeURIComponent(course.name)}?id=${course.id}`
          }))
        setCourses(formatted)
      } catch (err) {
        console.error('خطا در دریافت کورس‌ها:', err)
        toast.error('خطا در دریافت کورس‌ها')
      } finally {
        setLoading(false)
      }
    }
    fetchCourses()
  }, [])

  if (loading) {
    return (
      <div className='flex justify-center items-center min-h-[60vh]'>
        <span className='text-gray-500 dark:text-gray-300'>در حال بارگذاری...</span>
      </div>
    )
  }

  return (
    <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center my-52'>
      {courses.map(course => (
        <article
          key={course.id}
          className='bg-white dark:bg-gray-900 rounded-3xl shadow-lg hover:shadow-2xl transition-shadow duration-300 w-full max-w-md overflow-hidden'
        >
          {course.imageSrc && (
            <div className='h-48 w-full relative'>
              <Image src={course.imageSrc} alt={course.title} fill className='object-cover' />
            </div>
          )}
          <div className='p-6 flex flex-col justify-between h-full'>
            <h2 className='text-xl font-bold text-gray-900 dark:text-gray-100'>{course.title}</h2>
            <p className='text-gray-600 dark:text-gray-400 mt-2 line-clamp-3'>{course.description}</p>
            <p className='text-gray-700 dark:text-gray-300 mt-3'>ظرفیت: {course.seats}</p>
            <div className='mt-4'>
              <Link
                href={course.href}
                className='block text-center px-5 py-2 bg-primary text-white rounded-full font-medium text-sm hover:bg-primary/90 transition-colors'
              >
                ثبت‌نام
              </Link>
            </div>
          </div>
        </article>
      ))}
    </div>
  )
}
