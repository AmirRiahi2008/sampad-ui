export interface Course {
  id: number
  title: string
  description: string
  seats: number
  href: string
  imageSrc: string
  Icon:string
}

export const courses: Course[] = [
  {
    id: 1,
    title: 'کلاس ریاضی برای برنامه‌نویسان',
    description:
      'تمرکز بر مفاهیم کلیدی ریاضی که در برنامه‌نویسی و الگوریتم‌ها کاربرد دارند: جبر خطی پایه، آمار و احتمال مقدماتی، تحلیل پیچیدگی و حل مسئلهٔ محاسباتی با مثال‌های عملی.',
    seats: 20,
    href: '/courses/register/math',
    imageSrc: '/assets/courses/math.png',
    Icon: ""
  },
  
]