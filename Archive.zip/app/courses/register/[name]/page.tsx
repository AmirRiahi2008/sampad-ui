'use client'
import { useSearchParams } from 'next/navigation'
import MultiStepFormClient from '@/app/components/register/MultiStepFormClient'

type Props = { params: { name: string } }

export default function Page({ params }: Props) {
  const courseName = decodeURIComponent(params.name || '')
  const searchParams = useSearchParams()
  const courseId = Number(searchParams.get('id')) || 0 // Convert to number

  return <MultiStepFormClient courseName={courseName} courseId={courseId} />
}