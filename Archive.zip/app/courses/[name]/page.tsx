import MultiStepFormClient from '@/app/components/register/MultiStepFormClient';
type Props = { params: { name: string } };

export default function Page({ params }: Props) {
  const courseName = decodeURIComponent(params.name || '');
  
 return   <MultiStepFormClient courseName={courseName} />;

}