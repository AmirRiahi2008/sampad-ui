"use client"
import { useEffect, useState } from "react";
import axios from "axios";

// const http = new 
const Gallery = () => {
  const[data,setData]= useState<any[]>();
    useEffect(()=>{
      axios.get("https://jsonplaceholder.typicode.com/photos").then((res) => {
        console.log(res.data)
        setData(res.data);
    });
    },[])
    
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols- md:grid-cols-2">
      {data?.map((item) => (
        <div key={item.id}>
          <img
            className="h-52 w-full max-w-full rounded-lg object-cover object-center"
            src={item.url}
            alt="gallery-photo"
          />
          <h1>{item.title} Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, inventore.</h1>
        </div>
      ))}
    </div>
  );
};
export default Gallery;
