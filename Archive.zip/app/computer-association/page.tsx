'use client'
import { useEffect, useState } from 'react'
import HttpService from '../services/http.service'
import Card from '../shared/MainCard'

const http = new HttpService()
const ComputerAssociation = () => {
  const [eventsList, setEventList] = useState<any>()
  useEffect(() => {
    http.get('computer-association').then((res: any) => {
      setEventList(res)
    })
  }, [])

  return (
    <section className='pb-10 pt-20 dark:bg-dark lg:pb-20 lg:pt-[120px]'>
      <div className='container mx-auto'>
        <div className='-mx-4 flex flex-wrap'>
          <div className='w-full px-4'>
            <div className='mx-auto mb-[60px] max-w-[510px] text-center'>
              <h2 className='mb-3 text-3xl font-bold leading-[1.2] text-dark dark:text-white sm:text-4xl md:text-[40px]'>
                انجمن تخصصی کامپیوتر
              </h2>
            </div>
          </div>
        </div>
        <div className='-mx-2 flex flex-wrap justify-center'>
          {eventsList?.map((item: any) => {
            return <Card key={item.id} id={item.id} title={item.title} imageSrc={''} />
          })}
        </div>
      </div>
    </section>
  )
}
export default ComputerAssociation
