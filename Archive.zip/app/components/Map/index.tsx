'use client'
import { MapContainer } from 'react-leaflet/MapContainer'

import 'leaflet-defaulticon-compatibility'
import 'leaflet-defaulticon-compatibility/dist/leaflet-defaulticon-compatibility.css'
import 'leaflet/dist/leaflet.css'
import { Marker, Popup, TileLayer } from 'react-leaflet'

const MapLocation = () => {
  return (
    <MapContainer center={[36.559030667210756, 53.1350487925218]} zoom={14} style={{ height: '100%', width: '100%' }}>
      <TileLayer
      
        // attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      />
      <Marker position={[36.55899700992575, 53.13506402030895]}>
        <Popup>اینجا دبیرستان است</Popup>
      </Marker>
    </MapContainer>
  )
}

export default MapLocation
