'use client'
import React from 'react'

export default function Step2({
  form,
  setForm,
  prev,
  next
}: {
  form: any
  setForm: (f: any) => void
  prev: () => void
  next: () => void
}) {
  return (
    <>
      <label className='flex items-center gap-3'>
        <input
          type='checkbox'
          checked={form.isSampad}
          onChange={e => setForm({ ...form, isSampad: e.target.checked })}
        />
        <span className='text-sm text-gray-700 dark:text-gray-200'>آیا دانش آموز سمپاد هستید؟</span>
      </label>

      <div className='flex justify-between mt-4'>
        <button type='button' onClick={prev} className='px-4 py-2 rounded-lg bg-gray-400 text-white'>
          قبلی
        </button>
        <button type='button' onClick={next} className='px-4 py-2 rounded-lg bg-indigo-600 text-white'>
          بعدی
        </button>
      </div>
    </>
  )
}