'use client'
import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Step1 from './Step1'
import Step2 from './Step2'
import Step3 from './Step3'
import End from './End'
import HttpService from '@/app/services/http.service'
import toast from 'react-hot-toast'

type Props = { courseName: string; courseId?: number }

const http = new HttpService()

export default function MultiStepFormClient({ courseName, courseId }: Props) {
  const [step, setStep] = useState(1)
  const [form, setForm] = useState({
    name: '',
    isSampad: false,
    national_code: '',
  })
  const [errors, setErrors] = useState<any>({})
  const [submitting, setSubmitting] = useState(false)
  const [registered, setRegistered] = useState(false)

  const next = () => {
    const e = validateStep(step)
    if (Object.keys(e).length === 0) {
      setErrors({})
      setStep(s => s + 1)
    } else setErrors(e)
  }

  const prev = () => setStep(s => Math.max(1, s - 1))

  const validateStep = (s: number) => {
    const e: any = {}
    if (s === 1) {
      if (!form.name.trim()) e.name = 'لطفاً نام خود را وارد کنید.'
      else if (form.name.length > 100) e.name = 'نام نباید بیشتر از 100 کاراکتر باشد.'
    }
    if (s === 3) {
      if (!form.national_code.trim()) e.national_code = 'کد ملی را وارد کنید.'
      else if (!/^\d{10}$/.test(form.national_code)) e.national_code = 'کد ملی باید 10 رقم باشد.'
    }

    return e
  
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const eerrs = validateStep(3)
    if (Object.keys(eerrs).length) return setErrors(eerrs)

    setSubmitting(true)
    setErrors({})

    const payload = {
      fullname: form.name.trim(),
      national_code: form.national_code.trim(),
      course_name: courseName,
      status: false,
      isSampad_student: form.isSampad ? 1 : 0,
      course: `${courseId}`
    }

    console.log(payload);
  

    try {
      await http.push(`${process.env.NEXT_PUBLIC_API_URL}/registration-module`, JSON.stringify(payload))
      toast.success('ثبت نام با موفقیت انجام شد')
      setRegistered(true)
    } catch (err: any) {
      console.error('Error while submitting:', err)
      setErrors({ server: 'خطا در ثبت اطلاعات. لطفاً دوباره تلاش کنید.' })
      toast.error('خطا در ثبت اطلاعات')
    } finally {
      setSubmitting(false)
    }
  }

  const cardVariants = {
    enter: { opacity: 0, scale: 0.96, y: 18 },
    center: { opacity: 1, scale: 1, y: 0 },
    exit: { opacity: 0, scale: 0.96, y: -18 }
  }

  const slideVariants = {
    enter: (direction: number) => ({ x: direction > 0 ? 120 : -120, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (direction: number) => ({ x: direction > 0 ? -120 : 120, opacity: 0 })
  }

if (registered) return <End form={form} />

  return (
    <div className='min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 p-4'>
      <div className='w-full max-w-2xl'>
        <motion.div
          key='form-card'
          variants={cardVariants}
          initial='enter'
          animate='center'
          exit='exit'
          transition={{ duration: 0.42 }}
          className='bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 md:p-10'
        >
          <h2 className='text-2xl font-semibold mb-4 text-gray-800 dark:text-gray-100'>
            ثبت نام کلاس {courseName}
          </h2>

          <div className='mb-6'>
            <div className='h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden'>
              <div
                style={{ width: `${(step / 3) * 100}%` }}
                className='h-full bg-gradient-to-r from-indigo-500 to-pink-500 transition-all'
              />
            </div>
          </div>

          <form onSubmit={handleSubmit} noValidate>
            <div className='space-y-6'>
              <AnimatePresence custom={step} mode='wait'>
                {step === 1 && (
                  <motion.div
                    key='s1'
                    custom={1}
                    variants={slideVariants}
                    initial='enter'
                    animate='center'
                    exit='exit'
                    transition={{ duration: 0.38 }}
                  >
                    <Step1 form={form} setForm={setForm} errors={errors} next={next} />
                  </motion.div>
                )}
                {step === 2 && (
                  <motion.div
                    key='s2'
                    custom={1}
                    variants={slideVariants}
                    initial='enter'
                    animate='center'
                    exit='exit'
                    transition={{ duration: 0.38 }}
                  >
                    <Step2 form={form} setForm={setForm} prev={prev} next={next} />
                  </motion.div>
                )}
                {step === 3 && (
                  <motion.div
                    key='s3'
                    custom={1}
                    variants={slideVariants}
                    initial='enter'
                    animate='center'
                    exit='exit'
                    transition={{ duration: 0.38 }}
                  >
                    <Step3
                      form={form}
                      setForm={setForm}
                      errors={errors}
                      submitting={submitting}
                      prev={prev}
                    />
                    <p className='mt-2 text-xs text-red-500'>لطفاً کیبورد خود را روی انگلیسی قرار دهید</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  )
}