'use client';
import React from 'react';

interface EndProps {
  form?: {
    name?: string;
    isSampad?: boolean;
  };
  message?: string;
}

export default function End({ form, message }: EndProps) {
  const name = form?.name || 'کاربر';
  const isSampad = !!form?.isSampad;

  const fee = isSampad ? '۵۰۰ هزار تومان' : '۱ میلیون تومان';

  return (
    <div className='h-[77vh] bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-10 text-center min-h-[300px] flex flex-col items-center justify-center gap-6'>
      <h3 className='text-2xl font-semibold text-gray-800 dark:text-gray-100'>
        {message || `${name} عزیز، ثبت‌نام انجام شد`}
      </h3>

      <div className='bg-indigo-600 text-white rounded-xl p-6 w-full max-w-md shadow-md'>
        <p className='text-lg font-semibold mb-2'>6037-9975-9914-7585</p>
        <p className='mb-1'>دبیرستان شهید بهشتی ساری</p>
    
        <p className='text-sm'>
          لطفا فیش واریزی را به شماره تلفن ۰۹۰۱۷۵۷۰۷۳۴ در ایتا به همراه نام کاربر و کدملی ارسال کنید
        </p>
        <p className='mt-4 font-medium'>هزینه ثبت نام: {fee}</p>
      </div>
    </div>
  );
}