'use client'
import React from 'react'

export default function Step3({
  form,
  setForm,
  errors,
  submitting,
  prev
}: {
  form: any
  setForm: (f: any) => void
  errors: any
  submitting: boolean
  prev: () => void
}) {
  return (
    <>
      <label className='block text-sm mb-2 text-gray-700 dark:text-gray-200'>کد ملی</label>
      <input
        type='text'
        value={form.national_code}
        onChange={e => setForm({ ...form, national_code: e.target.value })}
        className='registerInput w-full p-3 rounded-lg border bg-transparent text-black border-gray-200 dark:border-gray-700'
        placeholder='کد ملی را وارد کنید'
      />
      {errors.national_code && <p className='mt-2 text-sm text-red-500'>{errors.national_code}</p>}

      <div className='flex justify-between mt-4'>
        <button type='button' onClick={prev} className='px-4 py-2 rounded-lg bg-gray-400 text-white'>
          قبلی
        </button>
        <button type='submit' className='px-4 py-2 rounded-lg bg-indigo-600 text-white' disabled={submitting}>
          {submitting ? 'در حال ارسال...' : 'ثبت نام'}
        </button>
      </div>
    </>
  )
}