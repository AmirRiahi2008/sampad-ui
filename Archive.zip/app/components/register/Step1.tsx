'use client'
import React from 'react'

export default function Step1({
  form,
  setForm,
  errors,
  next
}: {
  form: any
  setForm: (f: any) => void
  errors: any
  next: () => void
}) {
  return (
    <>
      <label className='block text-sm mb-2 text-gray-700 dark:text-gray-200'>نام کامل</label>
      <input
        value={form.name}
        onChange={e => setForm({ ...form, name: e.target.value })}
        className='registerInput w-full p-3 rounded-lg border bg-transparent text-black border-gray-200 dark:border-gray-700'
        placeholder='مثال: امیررضا ریاحی'
      />
      {errors.name && <p className='mt-2 text-sm text-red-500'>{errors.name}</p>}

      <div className='flex justify-end mt-4'>
        <button type='button' onClick={next} className='px-4 py-2 rounded-lg bg-indigo-600 text-white'>
          بعدی
        </button>
      </div>
    </>
  )
}