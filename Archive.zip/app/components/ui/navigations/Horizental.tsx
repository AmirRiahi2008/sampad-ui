import {
  Navbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  Link,
  Button,
  NavbarMenu,
  NavbarMenuToggle,
  NavbarMenuItem
} from '@nextui-org/react'
import { Logo } from '../logo/Logo'
import { navList } from '@/app/shared/NavigationList'

export default function Header() {
  return (
    <div className='fixed left-0 top-0 right-[-18rem] z-50'>
      <Navbar
        shouldHideOnScroll
        className='w-full h-20 bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-gray-200/20'
      >
        <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex items-center justify-between'>
          <NavbarBrand className='flex-none'>
            <Logo />
          </NavbarBrand>

          <NavbarContent className='hidden sm:flex flex-1 justify-center gap-6'>
            {navList.map(item => (
              <NavbarItem key={item.title}>
                <Link
                  href={item.link}
                  className='text-gray-600 dark:text-gray-300 text-sm font-medium hover:text-primary transition-colors duration-200 px-2 py-1 rounded-md hover:bg-primary/5'
                >
                  {item.title}
                </Link>
              </NavbarItem>
            ))}
          </NavbarContent>

          <NavbarContent className='hidden sm:flex items-center gap-2'>
            <NavbarItem>
              <Button
                as={Link}
                href='https://panel.sampad.school/'
                className='bg-primary/10 text-primary hover:bg-primary/20 font-medium px-6'
                variant='flat'
                radius='full'
              >
                ورود به پنل
              </Button>
            </NavbarItem>
            <NavbarItem>
              <Button
                as={Link}
                href='https://azmoon.sampad.school/'
                className='bg-secondary text-white hover:bg-secondary/20 font-medium px-6'
                variant='flat'
                radius='full'
              >
                ورود به بخش آزمون
              </Button>
            </NavbarItem>
          </NavbarContent>

          <NavbarContent className='sm:hidden'>
            <NavbarMenuToggle className='text-gray-600 dark:text-gray-300' />
          </NavbarContent>
        </div>

        <NavbarMenu className='sm:hidden fixed inset-0 z-40 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl'>
          <div className='w-full h-full flex items-center justify-center'>
            <div className='w-full max-w-md mx-4 p-6 flex flex-col gap-4'>
              {navList.map(item => (
                <NavbarMenuItem key={item.title} className='p-0'>
                  <Link
                    href={item.link}
                    className='block w-full text-center px-4 py-3 text-gray-600 dark:text-gray-300 hover:text-primary hover:bg-primary/5 rounded-lg transition-colors duration-200'
                  >
                    {item.title}
                  </Link>
                </NavbarMenuItem>
              ))}

              <NavbarMenuItem className='p-0 mt-4 flex flex-col gap-3'>
                <Button
                  as={Link}
                  href='https://panel.sampad.school/'
                  className='w-full bg-primary text-white hover:bg-primary/90 font-medium'
                  size='lg'
                >
                  ورود به پنل
                </Button>
                <Button
                  as={Link}
                  href='https://azmoon.sampad.school/'
                  className='w-full bg-secondary text-white hover:bg-secondary/90 font-medium'
                  size='lg'
                >
                  ورود به بخش آزمون
                </Button>
              </NavbarMenuItem>
            </div>
          </div>
        </NavbarMenu>
      </Navbar>
    </div>
  )
}