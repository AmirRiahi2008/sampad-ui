import { Image } from '@nextui-org/react'

export const Logo = () => <Image src='/assets/Sampad.png' width={50} height={50} />
