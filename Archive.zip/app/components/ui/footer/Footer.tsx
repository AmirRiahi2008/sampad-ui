'use client'
import Link from 'next/link'
import {
  FaFacebookF,
  FaPhoneAlt,
  FaEnvelope,
  FaVideo,
  FaInstagram,
  FaTelegram,
  FaLinkedin,
  FaMapMarkerAlt,
  FaCalendarAlt
} from 'react-icons/fa'

const Footer = () => {
  return (
    <footer className='bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800'>
      <div className='mx-auto max-w-7xl px-4 sm:px-6 lg:px-8'>
        {/* Newsletter Section */}
        <div className='py-12 border-b border-gray-200 dark:border-gray-800'>
          <div className='flex flex-col md:flex-row items-center justify-between gap-6'>
            <div className='text-center md:text-right'>
              <h3 className='text-xl font-bold text-gray-900 dark:text-white mb-2'>عضویت در خبرنامه</h3>
              <p className='text-gray-600 dark:text-gray-400'>برای دریافت آخرین اخبار و رویدادها عضو شوید</p>
            </div>
            <div className='w-full md:w-auto'>
              <form className='flex gap-2'>
                <input
                  type='email'
                  placeholder='ایمیل خود را وارد کنید'
                  className='flex-1 px-4 py-2 rounded-full border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-primary/20'
                />
                <button className='px-6 py-2 bg-primary text-white rounded-full hover:bg-primary/90 transition-colors'>
                  عضویت
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Main Footer Content */}
        <div className='py-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8'>
          {/* About Section */}
          <div>
            <h3 className='text-lg font-bold text-gray-900 dark:text-white mb-4'>درباره ما</h3>
            <p className='text-gray-600 dark:text-gray-400 leading-relaxed'>
              دبیرستان شهید بهشتی سمپاد یکی از معتبرترین مدارس استان مازندران است که با محیطی پویا و امکانات پیشرفته،
              دانش‌آموزان را برای موفقیت در مسیر تحصیلی و زندگی آماده می‌کند.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className='text-lg font-bold text-gray-900 dark:text-white mb-4'>دسترسی سریع</h3>
            <ul className='space-y-3'>
              {['درباره ما', 'خدمات ما', 'تماس با ما', 'اخبار و رویدادها', 'گالری تصاویر'].map(item => (
                <li key={item}>
                  <a
                    href='#'
                    className='text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary transition-colors flex items-center gap-2'
                  >
                    <span className='w-1.5 h-1.5 rounded-full bg-primary/60'></span>
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Latest News */}
          <div>
            <h3 className='text-lg font-bold text-gray-900 dark:text-white mb-4'>آخرین اخبار</h3>
            <div className='space-y-4'>
              {[
                { title: 'کسب رتبه برتر در المپیاد', date: '۱۴۰۲/۱۲/۱۵' },
                { title: 'برگزاری جشنواره علمی', date: '۱۴۰۲/۱۲/۱۰' }
              ].map(news => (
                <a key={news.title} href='#' className='block group'>
                  <h4 className='text-gray-700 dark:text-gray-300 group-hover:text-primary transition-colors'>
                    {news.title}
                  </h4>
                  <p className='text-sm text-gray-500 dark:text-gray-400 flex items-center gap-1'>
                    <FaCalendarAlt className='text-primary/60' />
                    {news.date}
                  </p>
                </a>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className='text-lg font-bold text-gray-900 dark:text-white mb-4'>اطلاعات تماس</h3>
            <div className='space-y-3'>
              <p className='flex items-center gap-3 text-gray-600 dark:text-gray-400'>
                <FaPhoneAlt className='text-primary' />
                4831835784
              </p>
              <p className='flex items-center gap-3 text-gray-600 dark:text-gray-400'>
                <FaEnvelope className='text-primary' />
                info@sampad.school
              </p>
              <p className='flex items-center gap-3 text-gray-600 dark:text-gray-400'>
                <FaMapMarkerAlt className='text-primary' />
                ساری‌ - مازندران - ایران
              </p>
              <Link
                href={'https://aparat.com/sampadsari1'}
                className='flex items-center gap-3 text-gray-600 dark:text-gray-400'
              >
                <FaVideo className='text-primary' />
                کانال آپارات
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className='py-6 border-t border-gray-200 dark:border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4'>
          <div className='flex items-center gap-4'>
            {[FaInstagram, FaTelegram, FaLinkedin, FaFacebookF].map((Icon, index) => (
              <a
                key={index}
                href='#'
                className='w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-primary hover:text-white transition-colors'
              >
                <Icon className='text-lg' />
              </a>
            ))}
          </div>

          <p className='text-gray-600 dark:text-gray-400 text-sm text-center'>
            © ۱۴۰۴ دبیرستان شهید بهشتی سمپاد. تمامی حقوق محفوظ است.
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
