'use client'

// ** React Imports
import { createContext, ReactNode, useEffect, useState } from 'react'

// ** Next Import
import { usePathname, useRouter } from 'next/navigation'

// ** Axios
import axios from 'axios'

// ** Config
import authConfig from '@/app/configs/auth'

// ** Types
import { AuthValuesType, LoginParams, UserDataType } from '@/app/types/auth.types'
import toast from 'react-hot-toast'

// ** Defaults
const defaultProvider: AuthValuesType = {
  user: null,
  loading: true,
  setUser: () => null,
  setLoading: () => Boolean,
  login: () => Promise.resolve(),
  logout: () => Promise.resolve()
}

const AuthContext = createContext(defaultProvider)

type Props = {
  children: ReactNode
}

const AuthProvider = ({ children }: Props) => {
  // ** States
  const [user, setUser] = useState<UserDataType | null>(defaultProvider.user)
  const [loading, setLoading] = useState<boolean>(defaultProvider.loading)

  // ** Hooks
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    const initAuth = async (): Promise<void> => {
      const storedToken = localStorage.getItem(authConfig.storageTokenKeyName)!
      console.log(storedToken)
      if (storedToken || storedToken == null) {
        setLoading(true)
        await axios
          .get(authConfig.meEndpoint, {
            headers: {
              Authorization: `Bearer ${storedToken}`
            }
          })
          .then(async response => {
            setLoading(false)
            const userData = response.data
            console.log(userData)
            setUser(response.data)
          })
          .catch(() => {
            toast.error('پروفایل کاربری یافت نشد دوباره تلاش کنید')
            localStorage.removeItem('userData')
            localStorage.removeItem('refreshToken')
            localStorage.removeItem('accessToken')
            setUser(null)
            setLoading(false)
            router.push('/login')
            if (!pathname.includes('login')) {
              router.replace('/login')
            }
          })
      } else {
        setLoading(false)
      }
    }

    initAuth()

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleLogin = (params: LoginParams) => {
    return new Promise((resolve, reject) => {
      console.log('authConfig.loginEndpoint', authConfig.loginEndpoint)
      axios
        .post(authConfig.loginEndpoint, params)
        .then(async (res: any) => {
          if (!res.data) {
            setUser(res.data.user)
            toast.error(res.data.message, {
              duration: 2000
            })
            reject(res.data)
          } else {
            toast.success(res.data.message, {
              duration: 2000
            })
            await window.localStorage.setItem(authConfig.storageTokenKeyName, res.data.access_token)
            const userData = res.data.user
            console.log(userData, 'user')
            setUser(res.data.user)
            await window.localStorage.setItem('userData', JSON.stringify(res.data))
            await router.push('/dashboard')
            resolve(res.data)
          }
        })
        .catch((err: { [key: string]: any }) => {
          const message = err.response ? err.response.data?.message : err.message
          toast.error(message, {
            duration: 2000
          })
          resolve(err)
        })
    })
  }

  const handleLogout = () => {
    window.localStorage.removeItem('userData')
    window.localStorage.removeItem(authConfig.storageTokenKeyName)
    setUser(null)
    router.push('/login')
  }

  const values = {
    user,
    loading,
    setUser,
    setLoading,
    login: handleLogin,
    logout: handleLogout
  }

  return <AuthContext.Provider value={values}>{children}</AuthContext.Provider>
}

export { AuthContext, AuthProvider }
