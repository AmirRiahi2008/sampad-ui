'use client'
import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import ServicesSection from './views/sections/howTo'
import Team from './views/sections/oldCeo/OldCeo'
import MessageQuoteSlider from './views/sections/messages/MessageComponent'
import LatestNews from './views/sections/latest-news'

const welcomeText = 'خوش آمدید به سمپاد ساری، جایی که استعدادها شکوفا می‌شوند'

export default function Home() {
  const [displayedText, setDisplayedText] = useState('')

  useEffect(() => {
    let currentIndex = 0
    const interval = setInterval(() => {
      if (currentIndex < welcomeText.length) {
        setDisplayedText(welcomeText.slice(0, currentIndex + 1))
        currentIndex++
      } else {
        clearInterval(interval)
      }
    }, 4000 / welcomeText.length)

    return () => clearInterval(interval)
  }, [])

  const sectionVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8 } }
  }

  return (
    <>
      <main className='flex flex-col w-screen'>
        <motion.section
          className='w-full min-h-screen flex flex-col justify-center items-center'
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <h1
            className='text-4xl md:text-5xl font-bold text-center mb-6'
            style={{ color: 'hsl(180.57deg 53.95% 38.36%)' }}
          >
            {displayedText}
          </h1>
          <motion.div
            className='flex space-x-4 mt-4'
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 2, duration: 0.8 }}
          >
            <div className='w-4 h-4 bg-[hsl(180.57deg_53.95%_38.36%)] rounded-full animate-bounce'></div>
            <div
              className='w-4 h-4 bg-[hsl(180.57deg_53.95%_38.36%)] rounded-full animate-bounce delay-200'
              style={{ marginRight: '1rem' }}
            ></div>
            <div className='w-4 h-4 bg-[hsl(180.57deg_53.95%_38.36%)] rounded-full animate-bounce delay-400'></div>
          </motion.div>
        </motion.section>

        <motion.section
          className='w-full h-0'
          initial='hidden'
          whileInView='visible'
          viewport={{ once: true, amount: 0.3 }}
          variants={sectionVariants}
        >
          <LatestNews />
        </motion.section>
        <motion.section
          className='w-full py-10'
          initial='hidden'
          whileInView='visible'
          viewport={{ once: true, amount: 0.3 }}
          variants={sectionVariants}
        >
          <ServicesSection />
        </motion.section>
        <motion.section
          className='w-full py-10'
          initial='hidden'
          whileInView='visible'
          viewport={{ once: true, amount: 0.3 }}
          variants={sectionVariants}
        >
          <Team />
        </motion.section>
        <motion.section
          className='w-full py-10'
          initial='hidden'
          whileInView='visible'
          viewport={{ once: true, amount: 0.3 }}
          variants={sectionVariants}
        >
          <MessageQuoteSlider />
        </motion.section>
      </main>
    </>
  )
}
