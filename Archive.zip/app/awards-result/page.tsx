'use client'

import { useEffect, useState } from 'react'
import HttpService from '../services/http.service'
import { motion } from 'framer-motion'

const http = new HttpService()

interface AwardType {
  id: number
  firstname: string
  lastname: string
  file_id: { path: string }
  medalNo: string
  awards_name: string
}

const AwardCard = ({ award }: { award: AwardType }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className='w-full sm:w-1/2 lg:w-1/3 p-4'
  >
    <div className='bg-white rounded-2xl overflow-hidden group hover:shadow-xl transition-all duration-300 border border-gray-100'>
      {/* Medal Badge */}
      <div className='absolute top-4 left-4 z-20'>
        <div className='flex items-center gap-2 px-3 py-1.5 bg-yellow-500/90 text-white rounded-full'>
          <svg className='w-4 h-4' fill='currentColor' viewBox='0 0 20 20'>
            <path d='M10 2a1 1 0 01.755.344l5.7 6.6a1 1 0 01-.332 1.6L10 14.002l-6.123-3.458a1 1 0 01-.332-1.6l5.7-6.6A1 1 0 0110 2z' />
            <path d='M6.5 12.5L10 14.002l3.5-1.502V17a1 1 0 01-1 1h-5a1 1 0 01-1-1v-4.498z' />
          </svg>
          <span className='font-bold text-sm'>مدال {award.medalNo}</span>
        </div>
      </div>

      {/* Image Container */}
      <div className='relative h-[260px] overflow-hidden'>
        <div className='absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent z-10' />
        <img
          src={award.file_id.path}
          alt={`${award.firstname} ${award.lastname}`}
          className='w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-300'
        />
      </div>

      {/* Content */}
      <div className='p-6'>
        <div className='mb-4'>
          <h3 className='text-xl font-bold text-gray-900 mb-2'>
            {award.firstname} {award.lastname}
          </h3>
          <div className='flex items-center gap-2 text-gray-600'>
            <svg className='w-5 h-5 text-primary' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
              <path
                strokeLinecap='round'
                strokeLinejoin='round'
                strokeWidth='2'
                d='M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1M15 12h4.5a2 2 0 012 2v4a2 2 0 01-2 2H15a2 2 0 01-2-2v-4a2 2 0 012-2z'
              />
            </svg>
            <span className='text-sm'>{award.awards_name}</span>
          </div>
        </div>

        {/* Achievement Details */}
        <div className='flex items-center justify-between pt-4 border-t border-gray-100'>
          <div className='flex items-center gap-2'>
            <span className='px-3 py-1 bg-primary/10 text-primary text-sm font-medium rounded-full'>دستاورد برتر</span>
          </div>
          <button className='text-primary hover:text-primary/80 font-medium text-sm flex items-center gap-1'>
            جزئیات بیشتر
            <svg className='w-4 h-4 rtl:rotate-180' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
              <path strokeLinecap='round' strokeLinejoin='round' strokeWidth='2' d='M9 5l7 7-7 7' />
            </svg>
          </button>
        </div>
      </div>
    </div>
  </motion.div>
)

const AwardsResult = () => {
  const [awards, setAwards] = useState<AwardType[]>([])

  useEffect(() => {
    http.get('awards-result').then((res: any) => {
      setAwards(res)
    })
  }, [])

  return (
    <div className='min-h-screen bg-gray-50 py-20'>
      <div className='container mx-auto px-4'>
        {/* Header Section */}
        <div className='max-w-3xl mx-auto text-center mb-16'>
          <span className='inline-block px-4 py-1 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4'>
            افتخارات
          </span>
          <h1 className='text-4xl font-bold text-gray-900 mb-6'>دستاوردهای درخشان دانش‌آموزان</h1>
          <p className='text-gray-600 leading-relaxed'>
            افتخار می‌کنیم که دانش‌آموزان ما با تلاش و پشتکار خود، موفق به کسب جوایز و مدال‌های ارزشمند شده‌اند.
          </p>
        </div>

        {/* Awards Grid */}
        <div className='flex flex-wrap -mx-4'>
          {awards.map(award => (
            <AwardCard key={award.id} award={award} />
          ))}
        </div>
      </div>
    </div>
  )
}

export default AwardsResult
