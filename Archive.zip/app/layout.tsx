import { NextUIProvider } from '@nextui-org/react'
import type { Metadata } from 'next'
import { Vazirmatn } from 'next/font/google'
import Footer from './components/ui/footer/Footer'
import HorizentalNavigation from './components/ui/navigations/Horizental'
import './globals.css'
import '@splidejs/react-splide/css/core'

const vazirMatn = Vazirmatn({
  subsets: ['arabic']
})

export const metadata: Metadata = {
  title: 'شهیدبهشتی ساری',
  description: 'سایت شهیدبهشتی ساری',
  icons: {
    icon: {
      url: '/favicon.png',
      type: 'image/png'
    },
    shortcut: { url: '/favicon.png', type: 'image/png' }
  }
}

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang='en' dir='rtl'>
      <body className={`${vazirMatn.className} !text-white`}>
        <link rel='icon' href='/favicon.ico' sizes='any' />
        <NextUIProvider>
          <HorizentalNavigation />
          <div className='conatiner'>{children}</div>
          <Footer />
        </NextUIProvider>
      </body>
    </html>
  )
}
