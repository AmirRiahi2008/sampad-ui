'use client'
import { motion } from 'framer-motion'

const About = () => {
  const fadeInUp = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  }

  return (
    <div className='min-h-screen'>
      {/* Hero Section */}
      <div className='relative overflow-hidden bg-white'>
        <div className='absolute inset-0 bg-[url("/grid.svg")] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]'></div>
        <div className='relative pt-16 pb-20 sm:pt-24 sm:pb-32'>
          <div className='mx-auto max-w-7xl px-6 lg:px-8'>
            <motion.div
              initial='hidden'
              whileInView='visible'
              viewport={{ once: true }}
              variants={fadeInUp}
              className='mx-auto max-w-3xl text-center'
            >
              <span className='inline-flex items-center rounded-full px-4 py-1 text-sm font-medium bg-primary/10 text-primary ring-1 ring-inset ring-primary/20'>
                درباره سمپاد
              </span>
              <h1 className='mt-6 text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl'>
                سازمان ملی استعدادهای درخشان
              </h1>
              <p className='mt-6 text-lg leading-8 text-gray-600'>
                سازمان ملی پرورش استعدادهای درخشان یا به اختصار سمپاد، نهادی است که بر امور تحصیلی دانش‌آموزان مستعد و
                با بهره هوشی بالا نظارت می‌کند.
              </p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className='py-24 sm:py-32 bg-gray-50'>
        <div className='mx-auto max-w-7xl px-6 lg:px-8'>
          <motion.div
            initial='hidden'
            whileInView='visible'
            viewport={{ once: true }}
            variants={fadeInUp}
            className='mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3'
          >
            <div>
              <h2 className='text-lg font-semibold leading-8 tracking-tight text-primary'>دبیرستان شهید بهشتی</h2>
              <p className='mt-2 text-3xl font-bold tracking-tight text-gray-900'>سمپاد ساری</p>
              <p className='mt-6 text-base leading-7 text-gray-600'>
                یکی از قدیمی‌ترین مراکز آموزشی سمپاد در استان مازندران با محیطی پویا و الهام‌بخش برای یادگیری
              </p>
            </div>

            <dl className='col-span-2 grid grid-cols-1 gap-x-8 gap-y-10 text-base leading-7 text-gray-600 sm:grid-cols-2'>
              <div className='relative pr-9'>
                <dt className='inline font-semibold text-gray-900'>
                  <svg className='absolute right-0 top-1 h-5 w-5 text-primary' viewBox='0 0 20 20' fill='currentColor'>
                    <path
                      fillRule='evenodd'
                      d='M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z'
                      clipRule='evenodd'
                    />
                  </svg>
                  آزمایشگاه‌های تخصصی
                </dt>
                <dd className='inline'> مجهز به پیشرفته‌ترین تجهیزات آموزشی و پژوهشی</dd>
              </div>
              <div className='relative pr-9'>
                <dt className='inline font-semibold text-gray-900'>
                  <svg className='absolute right-0 top-1 h-5 w-5 text-primary' viewBox='0 0 20 20' fill='currentColor'>
                    <path
                      fillRule='evenodd'
                      d='M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z'
                      clipRule='evenodd'
                    />
                  </svg>
                  کتابخانه و سالن مطالعه
                </dt>
                <dd className='inline'> فضایی آرام و مناسب برای مطالعه و پژوهش</dd>
              </div>
              <div className='relative pr-9'>
                <dt className='inline font-semibold text-gray-900'>
                  <svg className='absolute right-0 top-1 h-5 w-5 text-primary' viewBox='0 0 20 20' fill='currentColor'>
                    <path
                      fillRule='evenodd'
                      d='M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z'
                      clipRule='evenodd'
                    />
                  </svg>
                  سالن اجتماعات
                </dt>
                <dd className='inline'> برگزاری مراسم‌ها و همایش‌های علمی و فرهنگی</dd>
              </div>
              <div className='relative pr-9'>
                <dt className='inline font-semibold text-gray-900'>
                  <svg className='absolute right-0 top-1 h-5 w-5 text-primary' viewBox='0 0 20 20' fill='currentColor'>
                    <path
                      fillRule='evenodd'
                      d='M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z'
                      clipRule='evenodd'
                    />
                  </svg>
                  کارگاه کامپیوتر
                </dt>
                <dd className='inline'> مجهز به جدیدترین سیستم‌های کامپیوتری</dd>
              </div>
            </dl>
          </motion.div>
        </div>
      </div>

      {/* Image Section */}
      <div className='relative isolate overflow-hidden bg-white py-24 sm:py-32'>
        <div className='mx-auto max-w-7xl px-6 lg:px-8'>
          <motion.div
            initial='hidden'
            whileInView='visible'
            viewport={{ once: true }}
            variants={fadeInUp}
            className='mx-auto max-w-2xl lg:mx-0 lg:max-w-none'
          >
            <div className='grid grid-cols-1 gap-x-8 gap-y-6 text-base leading-7 text-gray-700 sm:grid-cols-2 lg:grid-cols-4'>
              <img
                src='https://via.placeholder.com/500x300'
                alt='School facilities'
                className='aspect-[3/2] w-full rounded-2xl object-cover shadow-lg'
              />
              <img
                src='https://via.placeholder.com/500x300'
                alt='Laboratory'
                className='aspect-[3/2] w-full rounded-2xl object-cover shadow-lg'
              />
              <img
                src='https://via.placeholder.com/500x300'
                alt='Library'
                className='aspect-[3/2] w-full rounded-2xl object-cover shadow-lg'
              />
              <img
                src='https://via.placeholder.com/500x300'
                alt='Computer lab'
                className='aspect-[3/2] w-full rounded-2xl object-cover shadow-lg'
              />
            </div>
          </motion.div>
        </div>
      </div>

      {/* CTA Section */}
      <div className='bg-white'>
        <div className='mx-auto max-w-7xl py-24 sm:px-6 sm:py-32 lg:px-8'>
          <motion.div
            initial='hidden'
            whileInView='visible'
            viewport={{ once: true }}
            variants={fadeInUp}
            className='relative isolate overflow-hidden bg-gray-900 px-6 py-16 shadow-2xl sm:rounded-3xl sm:px-16 md:pt-24 lg:flex lg:gap-x-20 lg:px-24 lg:pt-0'
          >
            <div className='mx-auto max-w-md text-center lg:mx-0 lg:flex-auto lg:py-32 lg:text-right'>
              <h2 className='text-3xl font-bold tracking-tight text-white sm:text-4xl'>می‌خواهید بیشتر بدانید؟</h2>
              <p className='mt-6 text-lg leading-8 text-gray-300'>
                برای کسب اطلاعات بیشتر درباره مدرسه و برنامه‌های آموزشی با ما در تماس باشید.
              </p>
              <div className='mt-10 flex items-center justify-center gap-x-6 lg:justify-end'>
                <a
                  href='#contact'
                  className='rounded-md bg-white px-6 py-3 text-sm font-semibold text-gray-900 shadow-sm hover:bg-gray-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white'
                >
                  تماس با ما
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

export default About
