const NotFoundPage = () => {
  return <h1>this is not found</h1>;
};

export default NotFoundPage;
