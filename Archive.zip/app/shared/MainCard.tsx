import Link from 'next/link'

const MainCard = ({
  id,
  title,
  imageSrc,
  description
}: {
  id: number
  title: string
  imageSrc: string
  description?: string
}) => {
  return (
    <div className='group bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1'>
      <div className='relative h-48 overflow-hidden'>
        <img
          src={imageSrc}
          alt={title}
          className='w-full h-full object-cover transition-transform duration-300 group-hover:scale-110'
        />
        <div className='absolute inset-0 bg-gradient-to-t from-black/60 to-transparent' />
      </div>
      <div className='p-6'>
        <h3 className='text-xl font-bold text-gray-900 dark:text-white mb-3 line-clamp-2'>{title}</h3>
        {description && (
          <div className='mb-4'>
            <p className='text-gray-600 dark:text-gray-300 line-clamp-2 text-sm leading-relaxed'>{description}</p>
          </div>
        )}
        <div className='flex items-center justify-between'>
          <Link
            href={`/news/${id}`}
            className='inline-flex items-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors text-sm'
          >
            ادامه مطلب
            <svg className='w-4 h-4 mr-2 rtl:ml-2 rtl:mr-0' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
              <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 5l7 7-7 7' />
            </svg>
          </Link>
          <span className='text-xs text-gray-500 dark:text-gray-400'>{new Date().toLocaleDateString('fa-IR')}</span>
        </div>
      </div>
    </div>
  )
}

export default MainCard
