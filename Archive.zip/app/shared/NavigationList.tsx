export const navList = [
  {
    title: 'خانه',
    link: '/'
  },
  {
    title: 'درباره ما',
    link: '/aboutus'
  },
  {
    title: 'ارتباط با ما',
    link: '/contact'
  },
  {
    title: 'اخبار',
    link: '/news'
  },
  {
    title: 'اساتید',
    link: '/team'
  },
  {
    title: 'انجمن کامپیوتر',
    link: '/computer-association'
  },
  {
    title: 'تالار افتخارات',
    link: '/awards-result'
  },
  {
    title:"الگوهای برتر تدریس دانش آموزی",
    link : "https://docs.google.com/forms/d/e/1FAIpQLSdYAf4k6KXTDWtlfB6D9gS1U7zy6hOk3S98KMqolMCRqpn8xg/viewform?usp=dialog"
  },{
    title : "دوره ها",
    link : "/courses"
  }
]
