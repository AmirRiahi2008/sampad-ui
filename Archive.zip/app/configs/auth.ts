let host =
  typeof window !== 'undefined' && window.location.hostname
    ? window.location.protocol + '//' + window.location.hostname
    : ''
if (host.includes('sampad')) {
  host = 'https://api.sampad.school/'
}
const baseUrl = process.env.NODE_ENV === 'production' ? `${host}/api/v1` : `${host}:4000/api/v1`

export default {
  baseUrl,
  meEndpoint: `${baseUrl}/user/profile`,
  loginEndpoint: `${baseUrl}/user/login`,
  storageTokenKeyName: 'accessToken',
  onTokenExpiration: 'refreshToken' // logout | refreshToken
}
